import 'package:final_project/src/my_app.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  runApp(const MyApp());
}
