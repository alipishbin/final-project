import 'dart:convert';

import 'package:either_dart/either.dart';
import 'package:final_project/src/infrastructure/commons/repository_urls.dart';
import 'package:final_project/src/pages/sign_up/models/sign_up_dto.dart';
import 'package:final_project/src/pages/sign_up/models/sign_up_view_model.dart';
import 'package:http/http.dart' as http;

class SignUpRepository {
  Future<Either<String, dynamic>> addUser({required SignUpDto model}) async {
    try {
      await Future.delayed(const Duration(seconds: 3));

      final url = Uri.http(RepositoryUrls.webBaseUrl, RepositoryUrls.users);
      final response = await http.post(
        url,
        body: jsonEncode(model.toJson()),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode >= 200 && response.statusCode < 400) {
        return const Right('success');
      } else {
        return Left("${response.statusCode}");
      }
    } catch (error) {
      return Left(error.toString());
    }
  }

  Future<Either<String, List<SignUpViewModel>>> fetchUsernameInfo() async {
    try {
      await Future.delayed(const Duration(seconds: 3));

      var url = Uri.http(RepositoryUrls.webBaseUrl, RepositoryUrls.users);
      final response = await http.get(url);
      if (response.statusCode >= 200 && response.statusCode < 400) {
        final List<dynamic> users = jsonDecode(response.body);
        final List<SignUpViewModel> listUsernameViewModel = [];
        for (var item in users) {
          final usersModel = SignUpViewModel.fromJson(item);
          listUsernameViewModel.add(usersModel);
        }
        return Right(listUsernameViewModel);
      } else {
        return Left('${response.statusCode}');
      }
    } catch (error) {
      return Left('$error');
    }
  }
}
