import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/pages/sign_up/controllers/sign_up_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SignUpPage extends GetView<SignUpController> {
  const SignUpPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.orange.shade300,
        body: _buildBody(context),
      );

  Widget _buildBody(BuildContext context) => SingleChildScrollView(
        child: Stack(
          children: [
            Positioned(
              child: Align(
                alignment: Alignment.topCenter,
                child: Column(
                  children: [
                    _manualSpace(height: 4),
                    const Image(
                      image: AssetImage('assets/Join_us.png'),
                      width: 120,
                      height: 108,
                      // fit: BoxFit.cover,
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              child: Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * .6,
                  height: MediaQuery.of(context).size.height * .9,
                  decoration: const BoxDecoration(
                    color: Color.fromRGBO(241, 100, 29, .2),
                  ),
                  child: _formFields(),
                ),
              ),
            ),
          ],
        ),
      );

  Widget _formFields() => SingleChildScrollView(
        child: Column(
          children: [
            _manualSpace(height: 70),
            _forms(),
            _radioButton(),
            _manualSpace(height: 8),
            _signUpButton(),
          ],
        ),
      );

  Widget _forms() => Form(
        key: controller.formKey,
        child: Column(
          children: [
            _textFormField(
              hintText: LocaleKeys.Enter_your_first_name.tr,
              label: LocaleKeys.first_name.tr,
              controller: controller.firstNameEditingController,
              validator: (value) => value != null && value.isNotEmpty
                  ? null
                  : LocaleKeys.first_name_cannot_be_empty.tr,
            ),
            _textFormField(
              hintText: LocaleKeys.Enter_your_last_name.tr,
              label: LocaleKeys.last_name.tr,
              controller: controller.lastNameEditingController,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return LocaleKeys.last_name_cannot_be_empty.tr;
                }
                return null;
              },
            ),
            _textFormField(
              hintText: LocaleKeys.Enter_your_username.tr,
              label: LocaleKeys.username.tr,
              controller: controller.userNameEditingController,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return LocaleKeys.username_cannot_be_empty.tr;
                }
                return null;
              },
            ),
            _textFormField(
              hintText: LocaleKeys.Enter_your_password.tr,
              label: LocaleKeys.password.tr,
              controller: controller.passwordEditingController,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return LocaleKeys.password_cannot_be_empty.tr;
                }
                return null;
              },
            ),
            _textFormField(
              hintText: LocaleKeys.Repeat_your_password.tr,
              label: LocaleKeys.repeat_password.tr,
              controller: controller.repeatPasswordEditingController,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return LocaleKeys.this_field_cannot_be_empty.tr;
                }
                return null;
              },
            ),
          ],
        ),
      );

  Widget _textFormField(
          {required String hintText,
          required TextEditingController controller,
          String? Function(String?)? validator,
          required String label}) =>
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 2),
        child: TextFormField(
          controller: controller,
          validator: validator,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.circular(20),
            ),
            hintText: hintText,
            label: Text(label),
            hintStyle: const TextStyle(color: Colors.black),
            filled: true,
            fillColor: Colors.grey.shade200,
          ),
        ),
      );

  Widget _radioButton() => Container(
        decoration: BoxDecoration(
          border: Border.all(width: 1, color: Colors.black12),
        ),
        child: Column(
          children: [
            Text(
              LocaleKeys.Select_Your_Role.tr,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            Obx(
              () {
                return RadioListTile(
                  visualDensity:
                      const VisualDensity(horizontal: -4, vertical: -4),
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  title: Text(LocaleKeys.customer.tr),
                  value: false,
                  groupValue: controller.isSeller.value,
                  onChanged: (value) {
                    controller.isSeller.value = value!;
                  },
                );
              },
            ),
            Obx(
              () {
                return RadioListTile(
                  visualDensity:
                      const VisualDensity(horizontal: -4, vertical: -4),
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  title: Text(LocaleKeys.seller.tr),
                  value: true,
                  groupValue: controller.isSeller.value,
                  onChanged: (value) {
                    controller.isSeller.value = value!;
                  },
                );
              },
            ),
          ],
        ),
      );

  Widget _signUpButton() => Obx(() {
        return controller.isLoadingSignUpButton.value
            ? Transform.scale(
                scale: 0.5,
                child: const Center(
                  child: CircularProgressIndicator(),
                ),
              )
            : Align(
                child: InkWell(
                  onTap: () {
                    controller.checkingConditions();
                  },
                  borderRadius: BorderRadius.circular(25),
                  child: Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 50, vertical: 8),
                    child: Container(
                      width: 420,
                      height: 35,
                      decoration: BoxDecoration(
                        color: Colors.teal,
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Center(
                        child: Text(
                          LocaleKeys.sign_up.tr,
                          style: const TextStyle(
                              fontSize: 20, color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
              );
      });

  Widget _manualSpace({required double height}) => SizedBox(
        height: height,
      );
}
