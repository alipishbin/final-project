import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/infrastructure/routes/route_names.dart';
import 'package:final_project/src/pages/sign_up/models/sign_up_dto.dart';
import 'package:final_project/src/pages/sign_up/models/sign_up_view_model.dart';
import 'package:final_project/src/pages/sign_up/repository/sign_up_repository.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SignUpController extends GetxController {
  final SignUpRepository _repository = SignUpRepository();

  TextEditingController firstNameEditingController = TextEditingController(),
      lastNameEditingController = TextEditingController(),
      userNameEditingController = TextEditingController(),
      passwordEditingController = TextEditingController(),
      repeatPasswordEditingController = TextEditingController();

  List<SignUpViewModel> usernames = [];
  RxBool isSeller = true.obs;
  RxBool isLoadingSignUp = false.obs;
  RxBool isLoadingSignUpButton = false.obs;

  final formKey = GlobalKey<FormState>();

  @override
  void onInit() {
    getUsernameInfo();
    super.onInit();
  }

  @override
  void onClose() {
    super.onClose();
    firstNameEditingController.clear();
    lastNameEditingController.clear();
    userNameEditingController.clear();
    passwordEditingController.clear();
    repeatPasswordEditingController.clear();
  }

  void signUp() async {
    isLoadingSignUp.value = true;
    isLoadingSignUpButton.value = true;
    final result = await _repository.addUser(model: _signUpDto());
    isLoadingSignUp.value = false;
    isLoadingSignUpButton.value = false;
    result.fold((left) {
      Get.showSnackbar(
        GetSnackBar(
          message: left,
          duration: const Duration(seconds: 2),
        ),
      );
    }, (right) {
      Get.snackbar(
          LocaleKeys.Well_Done.tr, LocaleKeys.user_successfully_added.tr);
      Get.offNamed(RouteNames.loginPageRoute);
    });
  }

  SignUpDto _signUpDto() => SignUpDto(
      firstName: firstNameEditingController.text.trim(),
      lastName: lastNameEditingController.text.trim(),
      userName: userNameEditingController.text.trim(),
      password: passwordEditingController.text.trim(),
      repeatPassword: repeatPasswordEditingController.text.trim(),
      isSeller: isSeller.value);

  Future<void> getUsernameInfo() async {
    final result = await _repository.fetchUsernameInfo();
    result.fold((left) => null, (right) => usernames.addAll(right));
  }

  void checkingConditions() {
    RxBool isRepeatedUsername = false.obs;
    for (final item in usernames) {
      if (item.userName == userNameEditingController.text) {
        isRepeatedUsername.value = true;
      }
    }

    if (!(formKey.currentState?.validate() ?? false)) {
      return;
    } else if (passwordEditingController.text !=
        repeatPasswordEditingController.text) {
      Get.showSnackbar(GetSnackBar(
        message: LocaleKeys.not_same_pass_entered.tr,
        duration: const Duration(seconds: 2),
        backgroundColor: Colors.redAccent,
      ));
      return;
    } else if (isRepeatedUsername.value == true) {
      Get.showSnackbar(GetSnackBar(
        message: LocaleKeys.same_username.tr,
        duration: const Duration(seconds: 2),
        backgroundColor: Colors.redAccent,
      ));
      return;
    } else if (firstNameEditingController.text.trim() == '' ||
        lastNameEditingController.text.trim() == '' ||
        userNameEditingController.text.trim() == '' ||
        passwordEditingController.text.trim() == '' ||
        repeatPasswordEditingController.text.trim() == '') {
      Get.showSnackbar(
        const GetSnackBar(
          message: 'Only space cannot be the correct value',
          duration: Duration(seconds: 2),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }
    signUp();
  }
}
