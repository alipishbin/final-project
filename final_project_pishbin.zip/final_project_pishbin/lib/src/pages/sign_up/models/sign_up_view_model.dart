class SignUpViewModel {
  final String userName;

  const SignUpViewModel({
    required this.userName,
  });

  factory SignUpViewModel.fromJson(final Map<String, dynamic> json) =>
      SignUpViewModel(
        userName: json["userName"],
      );
}
