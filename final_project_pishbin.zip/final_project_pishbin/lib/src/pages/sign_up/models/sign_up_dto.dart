class SignUpDto {
  final String firstName;
  final String lastName;
  final String userName;
  final String password;
  final String repeatPassword;
  final bool isSeller;

  const SignUpDto(
      {required this.firstName,
      required this.lastName,
      required this.userName,
      required this.password,
      required this.repeatPassword,
      required this.isSeller});

  Map<String, dynamic> toJson() => {
        'firstName': firstName,
        'lastName': lastName,
        'userName': userName,
        'password': password,
        'repeatPassword': repeatPassword,
        'isSeller': isSeller
      };
}
