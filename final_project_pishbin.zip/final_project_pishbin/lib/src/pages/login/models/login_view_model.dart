class LoginViewModel {
  final String id;
  final String userName;
  final String password;
  final bool isSeller;

  const LoginViewModel(
      {required this.id,
      required this.userName,
      required this.password,
      required this.isSeller});

  factory LoginViewModel.fromJson(final Map<String, dynamic> json) =>
      LoginViewModel(
          id: json['id'],
          userName: json["userName"],
          password: json["password"],
          isSeller: json["isSeller"]);
}
