import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/pages/login/controllers/login_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginPage extends GetView<LoginController> {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: SizedBox(
            width: MediaQuery.of(context).size.width * .6,
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _titleImage(),
                  _manualSpace(height: 18),
                  _titleText(),
                  _manualSpace(height: 8),
                  _forms(),
                  _manualSpace(height: 8),
                  _rememberMe(),
                  _manualSpace(height: 8),
                  _loginButton(),
                  _signUp(),
                  _manualSpace(height: 8),
                  _multiLanguage(),
                  _manualSpace(height: 8),
                ],
              ),
            ),
          ),
        ),
      );

  Widget _titleImage() {
    return const Image(
      image: AssetImage('assets/kindpng_7623560_012748.png'),
      alignment: Alignment.center,
      height: 250,
    );
  }

  Widget _titleText() => Center(
          child: Column(
        children: [
          Text(
            LocaleKeys.log_in_to_enter_the_shop.tr,
            style: const TextStyle(
                color: Colors.black, fontWeight: FontWeight.bold, fontSize: 24),
          ),
          Text(
            LocaleKeys.To_sell_or_buy_a_product_you_will_need_a_free_account.tr,
            style: const TextStyle(
              color: Colors.grey,
              fontSize: 14,
            ),
          )
        ],
      ));

  Widget _usernameTextField() => Padding(
        padding: const EdgeInsets.all(8.0),
        child: TextFormField(
          controller: controller.userNameEditingController,
          // onChanged: (value) =>
          //     controller.userNameEditingController.text = value,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return LocaleKeys.username_cannot_be_empty.tr;
            }
            return null;
          },
          autovalidateMode: AutovalidateMode.onUserInteraction,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.circular(20),
            ),
            hintText: LocaleKeys.Enter_your_username.tr,
            label: Text(LocaleKeys.username.tr),
            hintStyle: const TextStyle(color: Colors.deepOrange),
            filled: true,
            fillColor: Colors.grey.shade200,
          ),
        ),
      );

  Widget _passwordTextField() => Padding(
        padding: const EdgeInsets.all(8.0),
        child: TextFormField(
          obscureText: controller.obscureText.value,
          controller: controller.passwordEditingController,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return LocaleKeys.password_cannot_be_empty.tr;
            }
            return null;
          },
          autovalidateMode: AutovalidateMode.onUserInteraction,
          decoration: InputDecoration(
            suffixIcon: IconButton(
              icon: const Icon(Icons.visibility_off),
              onPressed: () => controller.toggleObscureText(),
            ),
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.circular(20),
            ),
            hintText: LocaleKeys.Enter_your_password.tr,
            label: Text(LocaleKeys.password.tr),
            hintStyle: const TextStyle(color: Colors.deepOrange),
            filled: true,
            fillColor: Colors.grey.shade200,
          ),
        ),
      );

  Widget _forms() => Form(
        key: controller.formKey,
        child: Column(
          children: [
            _usernameTextField(),
            _manualSpace(height: 8),
            Obx(() {
              return _passwordTextField();
            }),
          ],
        ),
      );

  Widget _rememberMe() => Obx(
        () => Row(
          children: [
            Checkbox(
              value: controller.rememberMe.value,
              onChanged: (value) => controller.toggleRememberMe(value!),
            ),
            Text(LocaleKeys.Remember_me.tr),
          ],
        ),
      );

  Widget _signUp() => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(LocaleKeys.Do_not_have_an_account__.tr),
          GestureDetector(
            onTap: () => controller.signUpTapped(),
            child: Text(
              LocaleKeys.sign_up.tr,
              style: const TextStyle(color: Colors.blue),
            ),
          ),
        ],
      );

  Widget _loginButton() => Obx(() {
        return controller.isLoadingLoginButton.value
            ? Transform.scale(
                scale: 0.5,
                child: const Center(
                  child: CircularProgressIndicator(),
                ),
              )
            : InkWell(
                onTap: () {
                  controller.getInfo();
                  controller.savingLoginData();
                },
                borderRadius: BorderRadius.circular(25),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 25),
                  child: Container(
                    width: 200,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.orange,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Center(
                      child: Text(
                        LocaleKeys.Login.tr,
                        style:
                            const TextStyle(fontSize: 20, color: Colors.white),
                      ),
                    ),
                  ),
                ),
              );
      });

  Widget _multiLanguage() => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextButton.icon(
            onPressed: () => controller.updateAppLanguage(
              locale: const Locale('fa', 'IR'),
            ),
            icon: const Icon(Icons.language),
            label: const Text('Fa'),
          ),
          TextButton.icon(
            onPressed: () => controller.updateAppLanguage(
              locale: const Locale('en', 'US'),
            ),
            icon: const Icon(Icons.language),
            label: const Text('En'),
          ),
        ],
      );

  Widget _manualSpace({required double height}) => SizedBox(
        height: height,
      );
}
