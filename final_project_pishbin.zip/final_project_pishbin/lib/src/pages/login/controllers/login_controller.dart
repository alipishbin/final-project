import 'package:either_dart/either.dart';
import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/infrastructure/commons/user_id.dart';
import 'package:final_project/src/infrastructure/routes/route_names.dart';
import 'package:final_project/src/pages/login/models/login_view_model.dart';
import 'package:final_project/src/pages/login/repositories/login_repository.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginController extends GetxController {
  final LoginRepository _repository = LoginRepository();

  TextEditingController userNameEditingController = TextEditingController(),
      passwordEditingController = TextEditingController();

  List<LoginViewModel> successfulLogins = [];
  final RxBool obscureText = true.obs;
  RxBool isLoadingLoginButton = false.obs;
  RxBool rememberMe = false.obs;

  @override
  void onInit() {
    loadLoginData();
    super.onInit();
  }

  @override
  void onClose() {
    super.onClose();
    userNameEditingController.clear();
    passwordEditingController.clear();
    successfulLogins.clear();
  }

  GlobalKey<FormState> formKey = GlobalKey();

  void signUpTapped() {
    Get.offNamed('${RouteNames.loginPageRoute}${RouteNames.singUpPageRoute}');
  }

  void toggleObscureText() {
    obscureText.toggle();
  }

  Future<void> getInfo() async {
    if (!(formKey.currentState?.validate() ?? false)) {
      return;
    }
    isLoadingLoginButton.value = true;
    final Either<String, List<LoginViewModel>> result =
        await _repository.fetchLoginInfo();
    isLoadingLoginButton.value = false;
    result.fold((left) {
      Get.showSnackbar(
        GetSnackBar(
          message: 'Error. status code: $left',
        ),
      );
    }, (right) {
      for (int i = 0; i < right.length; i++) {
        if (right.elementAt(i).userName == userNameEditingController.text &&
            right.elementAt(i).password == passwordEditingController.text &&
            right.elementAt(i).isSeller == false) {
          successfulLogins.add(right[i]);
          UserInfo.userId = right.elementAt(i).id;
          Get.offNamed(RouteNames.customerHomePageRoute);
        } else if (right.elementAt(i).userName ==
                userNameEditingController.text &&
            right.elementAt(i).password == passwordEditingController.text &&
            right.elementAt(i).isSeller == true) {
          successfulLogins.add(right[i]);
          UserInfo.userId = right.elementAt(i).id;
          Get.offNamed(
            RouteNames.sellerPageRoute,
          );
        } else if (right.elementAt(i).userName ==
                userNameEditingController.text &&
            right.elementAt(i).password != passwordEditingController.text) {
          successfulLogins.add(right[i]);
          Get.showSnackbar(
            GetSnackBar(
              backgroundColor: Colors.red,
              duration: const Duration(seconds: 2),
              message: LocaleKeys.wrong_password.tr,
            ),
          );
        }
      }
      if (successfulLogins.isEmpty) {
        Get.showSnackbar(
          GetSnackBar(
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 2),
            message: LocaleKeys.You_must_sign_up_first.tr,
          ),
        );
      }
    });
  }

  void updateAppLanguage({required Locale locale}) => Get.updateLocale(locale);

  void toggleRememberMe(bool value) {
    rememberMe.value = value;
  }

  Future<void> savingLoginData() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    if (rememberMe.value == true) {
      await prefs.setBool('rememberMe', rememberMe.value);
      await prefs.setString('username', userNameEditingController.text);
      await prefs.setString('password', passwordEditingController.text);
    } else {
      await prefs.remove('username');
      await prefs.remove('password');
      await prefs.remove('rememberMe');
    }
  }

  Future<void> loadLoginData() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    userNameEditingController.text = prefs.getString('username') ?? '';
    passwordEditingController.text = prefs.getString('password') ?? '';
  }
}
