import 'dart:convert';

import 'package:either_dart/either.dart';
import 'package:http/http.dart' as http;

import '../../../infrastructure/commons/repository_urls.dart';
import '../models/login_view_model.dart';

class LoginRepository {
  Future<Either<String, List<LoginViewModel>>> fetchLoginInfo() async {
    try {
      await Future.delayed(const Duration(seconds: 1));

      var url = Uri.http(RepositoryUrls.webBaseUrl, RepositoryUrls.users);
      final response = await http.get(url);
      if (response.statusCode >= 200 && response.statusCode < 400) {
        final List<dynamic> users = jsonDecode(response.body);
        final List<LoginViewModel> listLoginViewModel = [];
        for (var item in users) {
          final usersModel = LoginViewModel.fromJson(item);
          listLoginViewModel.add(usersModel);
        }
        return Right(listLoginViewModel);
      } else {
        return Left('${response.statusCode}');
      }
    } catch (error) {
      return Left('$error');
    }
  }
}
