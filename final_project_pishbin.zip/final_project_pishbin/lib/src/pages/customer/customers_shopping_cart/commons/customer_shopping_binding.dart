import 'package:final_project/src/pages/customer/customers_shopping_cart/controllers/customer_shopping_controller.dart';
import 'package:get/get.dart';

class CustomerShoppingBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => CustomerShoppingController());
  }
}
