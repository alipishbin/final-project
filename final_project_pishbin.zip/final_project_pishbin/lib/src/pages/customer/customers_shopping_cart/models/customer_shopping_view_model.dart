class CustomerShoppingViewModel {
  final String id;
  final String sellerId;
  final String customerId;
  final String title;
  final int price;
  final int quantity;
  final int selectedNumber;

  const CustomerShoppingViewModel({
    required this.id,
    required this.sellerId,
    required this.customerId,
    required this.title,
    required this.price,
    required this.quantity,
    required this.selectedNumber,
  });

  factory CustomerShoppingViewModel.fromJson(final Map<String, dynamic> json) =>
      CustomerShoppingViewModel(
          id: json['id'],
          sellerId: json['sellerId'],
          customerId: json['customerId'],
          title: json['title'],
          price: json['price'],
          selectedNumber: json['selectedNumber'],
          quantity: json['quantity']);
}
