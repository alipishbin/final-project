class CustomerDto {
  final String id;
  final String customerId;
  final String sellerId;
  final String title;
  final int price;
  final int quantity;
  final int selectedNumber;

  CustomerDto({
    required this.id,
    required this.sellerId,
    required this.customerId,
    required this.title,
    required this.price,
    required this.quantity,
    required this.selectedNumber,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'sellerId': sellerId,
      'customerId': customerId,
      'title': title,
      'price': price,
      'quantity': quantity,
      'selectedNumber': selectedNumber,
    };
  }
}
