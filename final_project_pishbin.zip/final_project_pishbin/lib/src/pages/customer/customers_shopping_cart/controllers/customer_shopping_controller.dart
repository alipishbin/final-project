import 'package:either_dart/either.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/models/customer_dto.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/models/customer_purchase_dto.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/models/customer_shopping_view_model.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/repositories/customer_shopping_repository.dart';
import 'package:get/get.dart';

class CustomerShoppingController extends GetxController {
  final CustomerShoppingRepository _repository = CustomerShoppingRepository();

  final RxBool isLoadingFetchingProductInfo = false.obs;
  final RxList<CustomerShoppingViewModel> selections =
      <CustomerShoppingViewModel>[].obs;

  RxMap<String, bool> isDeleteLoadingMap = RxMap();
  final RxInt totalCost = RxInt(0);

  @override
  void onInit() {
    getSelectionList();
    getTotalCost();
    super.onInit();
  }

  void getSelectionList() async {
    isLoadingFetchingProductInfo.value = true;
    final Either<String, List<CustomerShoppingViewModel>> result =
        await _repository.fetchingSelectionList();
    isLoadingFetchingProductInfo.value = false;

    result.fold((left) {
      Get.showSnackbar(
        GetSnackBar(
          message: 'Error. status code: $left',
        ),
      );
    }, (right) {
      selections.addAll(right);
    });
  }

  Future<void> deleteSelectionFromCart({required String id}) async {
    isDeleteLoadingMap[id] = true;
    final result = await _repository.deleteSelection(id: id);
    isDeleteLoadingMap[id] = false;
    result.fold((left) {
      Get.showSnackbar(
        GetSnackBar(
          title: left,
        ),
      );
    }, (right) {
      selections.removeWhere((element) => element.id == id);
      getTotalCost();
    });
  }

  void getTotalCost() async {
    final Either<String, List<CustomerShoppingViewModel>> result =
        await _repository.fetchingSelectionList();
    result.fold((left) {
      Get.showSnackbar(
        GetSnackBar(
          message: 'Error. status code: $left',
        ),
      );
    }, (right) {
      totalCost.value = 0;
      for (final item in right) {
        totalCost.value += item.price * item.selectedNumber;
      }
    });
  }

  void onIncrease(
      CustomerShoppingViewModel product, int value, int index) async {
    CustomerDto dto = CustomerDto(
      id: product.id,
      sellerId: product.sellerId,
      customerId: product.customerId,
      title: product.title,
      price: product.price,
      quantity: product.quantity,
      selectedNumber: value,
    );
    final result = _repository.changeProductNumber(dto: dto);
    result.fold((left) {
      Get.showSnackbar(
        GetSnackBar(
          title: left,
        ),
      );
    }, (right) {
      selections[index] = right;
      getTotalCost();
    });
  }

  void onDecrease(
      CustomerShoppingViewModel product, int value, int index) async {
    CustomerDto dto = CustomerDto(
      id: product.id,
      customerId: product.customerId,
      sellerId: product.sellerId,
      title: product.title,
      price: product.price,
      quantity: product.quantity,
      selectedNumber: value,
    );
    final result = _repository.changeProductNumber(dto: dto);
    result.fold((left) {
      Get.showSnackbar(
        GetSnackBar(
          title: left,
        ),
      );
    }, (right) {
      selections[index] = right;
      getTotalCost();
    });
  }

  void payment() async {
    for (final item in selections) {
      CustomerPurchaseDto dto = CustomerPurchaseDto(
          id: item.id, quantity: item.quantity - item.selectedNumber);
      await _repository.changeProductQuantity(dto: dto);
      await _repository.deleteSelection(id: dto.id);
    }
    Get.back();
  }
}
