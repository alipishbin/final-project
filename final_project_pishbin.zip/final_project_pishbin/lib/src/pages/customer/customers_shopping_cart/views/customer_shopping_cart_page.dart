import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/controllers/customer_shopping_controller.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/views/widgets/shopping_item_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CustomerShoppingCartPage extends GetView<CustomerShoppingController> {
  const CustomerShoppingCartPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.orangeAccent,
          title: Center(
            child: Text(LocaleKeys.Shopping_cart.tr),
          ),
        ),
        body: _buildBody(context),
      );

  Widget _buildBody(BuildContext context) => Obx(
        () {
          return controller.isLoadingFetchingProductInfo.value
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : Center(
                  child: Container(
                    width: MediaQuery.of(context).size.width * .9,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.orange,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      children: [
                        Expanded(child: _listPurchasedItem()),
                        _buttons(),
                      ],
                    ),
                  ),
                );
        },
      );

  Widget _buttons() => Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [_totalCost(), _payment()],
      );

  Widget _payment() => SizedBox(
        height: 40,
        width: 140,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red,
          ),
          onPressed: () => controller.payment(),
          child: Center(
            child: Text(
              LocaleKeys.Payment.tr,
              style: const TextStyle(color: Colors.white),
            ),
          ),
        ),
      );

  Widget _totalCost() => Padding(
        padding: const EdgeInsets.all(10),
        child: Container(
          height: 40,
          width: 230,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24), color: Colors.grey),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(LocaleKeys.Total_cost_is.tr),
              const Icon(Icons.arrow_right_alt_outlined),
              Obx(() {
                return Text(
                  '${controller.totalCost.value}' '\$',
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, color: Colors.red),
                );
              }),
            ],
          ),
        ),
      );

  Widget _listPurchasedItem() => ListView.builder(
        itemBuilder: (context, index) =>
            ShoppingItemView(item: controller.selections[index], index: index),
        itemCount: controller.selections.length,
      );
}
