import 'package:final_project/src/infrastructure/component/custom_number_picker/number_picker.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/controllers/customer_shopping_controller.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/models/customer_shopping_view_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ShoppingItemView extends GetView<CustomerShoppingController> {
  final CustomerShoppingViewModel item;
  final int index;

  const ShoppingItemView({required this.item, required this.index, super.key});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.all(4),
        padding: const EdgeInsets.all(12.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Colors.lightGreen.shade200,
        ),
        child: Column(
          children: [
            _nameAndDelete(),
            _priceAndNumberPicker(),
          ],
        ),
      );

  Widget _nameAndDelete() => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(item.title),
          Obx(
            () => controller.isDeleteLoadingMap[item.id] ?? false
                ? Transform.scale(
                    scale: 0.5, child: const CircularProgressIndicator())
                : IconButton(
                    onPressed: () =>
                        controller.deleteSelectionFromCart(id: item.id),
                    icon: const Icon(Icons.delete),
                  ),
          ),
        ],
      );

  Widget _priceAndNumberPicker() => Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Text('${item.price}' ' \$'),
          _numberPicker(item, index),
        ],
      );

  Widget _numberPicker(CustomerShoppingViewModel item, int index) =>
      CustomNumberPicker(
        initialValue: item.selectedNumber,
        minValue: 1,
        maxValue: item.quantity,
        onIncrease: (value) => controller.onIncrease(item, value, index),
        onDecrease: (value) => controller.onDecrease(item, value, index),
      );
}
