import 'dart:convert';

import 'package:either_dart/either.dart';
import 'package:final_project/src/infrastructure/commons/user_id.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/models/customer_dto.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/models/customer_purchase_dto.dart';
import 'package:http/http.dart' as http;

import '../../../../infrastructure/commons/repository_urls.dart';
import '../models/customer_shopping_view_model.dart';

class CustomerShoppingRepository {
  Future<Either<String, List<CustomerShoppingViewModel>>>
      fetchingSelectionList() async {
    try {
      await Future.delayed(const Duration(seconds: 1));

      var url = Uri.http(RepositoryUrls.webBaseUrl, RepositoryUrls.selections,
          {'customerId': UserInfo.userId});
      final response = await http.get(url);
      if (response.statusCode >= 200 && response.statusCode < 400) {
        final List<dynamic> selections = jsonDecode(response.body);
        final List<CustomerShoppingViewModel> listOfSelections = [];
        for (var item in selections) {
          final selectionModel = CustomerShoppingViewModel.fromJson(item);
          listOfSelections.add(selectionModel);
        }
        return Right(listOfSelections);
      } else {
        return Left('${response.statusCode}');
      }
    } catch (error) {
      return Left('$error');
    }
  }

  Future<Either<String, String>> deleteSelection({required String id}) async {
    try {
      await Future.delayed(
        const Duration(seconds: 1),
      );
      final url =
          Uri.http(RepositoryUrls.webBaseUrl, RepositoryUrls.editSelection(id));
      final response = await http.delete(url);
      if (response.statusCode >= 200 && response.statusCode <= 400) {
        return Right(response.body);
      } else {
        return Left('${response.statusCode}');
      }
    } catch (error) {
      return Left('$error');
    }
  }

  Future<Either<String, CustomerShoppingViewModel>> changeProductNumber(
      {required CustomerDto dto}) async {
    try {
      await Future.delayed(const Duration(seconds: 1));
      final url = Uri.http(
          RepositoryUrls.webBaseUrl, RepositoryUrls.editSelection(dto.id));

      final response = await http.put(
        url,
        body: jsonEncode(dto.toJson()),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode >= 200 && response.statusCode < 400) {
        final Map<String, dynamic> json = jsonDecode(response.body);
        final CustomerShoppingViewModel editProducts =
            CustomerShoppingViewModel.fromJson(json);
        return Right(editProducts);
      } else {
        return Left('${response.statusCode}');
      }
    } catch (error) {
      return Left('$error');
    }
  }

  Future<Either<String, CustomerShoppingViewModel>> changeProductQuantity(
      {required CustomerPurchaseDto dto}) async {
    try {
      await Future.delayed(const Duration(seconds: 1));
      final url = Uri.http(
          RepositoryUrls.webBaseUrl, RepositoryUrls.editProduct(dto.id));

      final response = await http.patch(
        url,
        body: jsonEncode(dto.toJson()),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode >= 200 && response.statusCode < 400) {
        final Map<String, dynamic> json = jsonDecode(response.body);
        final CustomerShoppingViewModel editProducts =
            CustomerShoppingViewModel.fromJson(json);
        return Right(editProducts);
      } else {
        return Left('${response.statusCode}');
      }
    } catch (error) {
      return Left('$error');
    }
  }
}
