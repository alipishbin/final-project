import 'dart:convert';

import 'package:either_dart/either.dart';
import 'package:final_project/src/infrastructure/commons/user_id.dart';
import 'package:final_project/src/pages/customer/customer_home_page/models/customer_page_view_model.dart';
import 'package:http/http.dart' as http;

import '../../../../infrastructure/commons/repository_urls.dart';
import '../models/customer_selection_view_model.dart';
import '../models/customer_selections_dto.dart';

class CustomerRepository {
  Future<Either<String, List<CustomerPageViewModel>>>
      fetchAndDisplayActiveProducts(
    int min,
    int max,
  ) async {
    if (min == 0 && max == 0) {
      try {
        await Future.delayed(const Duration(seconds: 1));

        var url = Uri.http(RepositoryUrls.webBaseUrl, RepositoryUrls.products);
        final response = await http.get(url);
        if (response.statusCode >= 200 && response.statusCode < 400) {
          final List<dynamic> products = jsonDecode(response.body);
          final List<dynamic> activeJson = products
              .where((element) =>
                  element['isActive'] == true && element['quantity'] > 0)
              .toList();
          final List<CustomerPageViewModel> activeProducts = [];
          for (var item in activeJson) {
            final productModel = CustomerPageViewModel.fromJson(item);
            activeProducts.add(productModel);
          }
          return Right(activeProducts);
        } else {
          return Left('${response.statusCode}');
        }
      } catch (error) {
        return Left('$error');
      }
    } else {
      try {
        await Future.delayed(const Duration(seconds: 1));

        var url = Uri.http(
          RepositoryUrls.webBaseUrl,
          RepositoryUrls.products,
        );
        final response = await http.get(url);
        if (response.statusCode >= 200 && response.statusCode < 400) {
          final List<dynamic> products = jsonDecode(response.body);
          final List<dynamic> activeJson = products
              .where((element) =>
                  element['isActive'] == true &&
                  element['quantity'] > 0 &&
                  element['price'] >= min &&
                  element['price'] <= max)
              .toList();
          final List<CustomerPageViewModel> activeProductsForFilter = [];
          for (var item in activeJson) {
            final productModel = CustomerPageViewModel.fromJson(item);
            activeProductsForFilter.add(productModel);
          }
          return Right(activeProductsForFilter);
        } else {
          return Left('${response.statusCode}');
        }
      } catch (error) {
        return Left('$error');
      }
    }
  }

  Future<Either<String, dynamic>> addSelectionByCustomer(
      {required CustomerSelectionDto model}) async {
    try {
      await Future.delayed(const Duration(seconds: 2));
      final url =
          Uri.http(RepositoryUrls.webBaseUrl, RepositoryUrls.selections);
      final response = await http.post(
        url,
        body: jsonEncode(model.toJson()),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode >= 200 && response.statusCode < 400) {
        return const Right('success');
      } else {
        return Left("${response.statusCode}");
      }
    } catch (error) {
      return Left(error.toString());
    }
  }

  Future<Either<String, List<CustomerSelectionViewModel>>>
      fetchSelectionListByCustomerId() async {
    try {
      await Future.delayed(const Duration(seconds: 3));

      var url = Uri.http(RepositoryUrls.webBaseUrl, RepositoryUrls.selections,
          {'customerId': UserInfo.userId});
      final response = await http.get(url);
      if (response.statusCode >= 200 && response.statusCode < 400) {
        final List<dynamic> products = jsonDecode(response.body);
        final List<CustomerSelectionViewModel> selectionsByCustomer = [];
        for (var item in products) {
          final productModel = CustomerSelectionViewModel.fromJson(item);
          selectionsByCustomer.add(productModel);
        }
        return Right(selectionsByCustomer);
      } else {
        return Left('${response.statusCode}');
      }
    } catch (error) {
      return Left('$error');
    }
  }

  Future<Either<String, List<CustomerPageViewModel>>>
      fetchProductListByPrice() async {
    try {
      await Future.delayed(const Duration(seconds: 1));

      var url = Uri.http(RepositoryUrls.webBaseUrl, RepositoryUrls.products, {
        '_sort': 'price',
      });
      final response = await http.get(url);
      if (response.statusCode >= 200 && response.statusCode < 400) {
        final List<dynamic> products = jsonDecode(response.body);
        final List<dynamic> activeJson = products
            .where((element) =>
                element['isActive'] == true && element['quantity'] > 0)
            .toList();
        final List<CustomerPageViewModel> activeProductsForPriceFiltering = [];
        for (var item in activeJson) {
          final productModel = CustomerPageViewModel.fromJson(item);
          activeProductsForPriceFiltering.add(productModel);
        }
        return Right(activeProductsForPriceFiltering);
      } else {
        return Left('${response.statusCode}');
      }
    } catch (error) {
      return Left('$error');
    }
  }
}
