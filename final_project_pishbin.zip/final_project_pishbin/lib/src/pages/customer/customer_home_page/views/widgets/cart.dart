import 'package:final_project/src/pages/customer/customer_home_page/controllers/customer_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ShoppingCart extends GetView<CustomerController> {
  const ShoppingCart({super.key});

  @override
  Widget build(BuildContext context) => Stack(
        alignment: AlignmentDirectional.center,
        children: [
          IconButton(
            onPressed: () => controller.onCartTapped(),
            icon: const Icon(
              Icons.shopping_cart_rounded,
              size: 30,
            ),
          ),
          Positioned(
            top: 4,
            right: 6,
            child: Container(
              height: 18,
              width: 18,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.red,
              ),
              child: Center(child: Obx(() {
                return Text(
                  '${controller.counter.value}',
                  style: const TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                  ),
                );
              })),
            ),
          ),
        ],
      );
}
