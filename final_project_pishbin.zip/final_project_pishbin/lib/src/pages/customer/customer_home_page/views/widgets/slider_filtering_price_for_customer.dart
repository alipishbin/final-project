import 'package:final_project/src/pages/customer/customer_home_page/controllers/customer_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SliderFilteringPriceForCustomer extends GetView<CustomerController> {
  const SliderFilteringPriceForCustomer({super.key});

  @override
  Widget build(BuildContext context) => Obx(() {
        return RangeSlider(
          values: controller.currentRangeValues.value,
          max: controller.max.value.toDouble(),
          min: controller.min.value.toDouble(),
          onChanged: (RangeValues values) {
            controller.currentRangeValues.value = values;
          },
        );
      });
}
