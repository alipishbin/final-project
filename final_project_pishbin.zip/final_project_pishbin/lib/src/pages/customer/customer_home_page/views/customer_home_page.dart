import 'package:custom_search/custom_search.dart';
import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/pages/customer/customer_home_page/controllers/customer_controller.dart';
import 'package:final_project/src/pages/customer/customer_home_page/views/widgets/cart.dart';
import 'package:final_project/src/pages/customer/customer_home_page/views/widgets/customer_product_item_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CustomerHomePage extends GetView<CustomerController> {
  const CustomerHomePage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: _appBar(context),
        body: _buildBody(context),
      );

  AppBar _appBar(context) => AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(LocaleKeys.Customer_home_page.tr),
            SizedBox(
              width: MediaQuery.of(context).size.width * .3,
            ),
            IconButton(
              onPressed: () => controller.onLogOutTapped(),
              icon: const Icon(Icons.logout),
            ),
          ],
        ),
        backgroundColor: Colors.orange.shade200,
      );

  Widget _buildBody(BuildContext context) => Obx(() {
        return controller.isLoadingFetchingProductInfo.value
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * .9,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.orange,
                      width: 2,
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    children: [
                      _header(),
                      Expanded(child: _gridProductItems()),
                    ],
                  ),
                ),
              );
      });

  Widget _packageCustomSearchBar() => CustomSearchBar(
        onSearchTextFieldChanged: (value) => controller.searchProducts(value),
        onClearSearchTap: () => controller.onClearSearchBarTap(),
        onFilterButtonTap: () => controller.openDialog(),
        searchTextController: controller.searchTextController,
      );

  Widget _header() => Row(
        children: [
          Expanded(
            child: _packageCustomSearchBar(),
          ),
          const ShoppingCart(),
        ],
      );

  Widget _gridProductItems() => GridView.builder(
        gridDelegate:
            const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemCount: controller.searchedProduct.length,
        itemBuilder: (context, index) => CustomerProductItemView(
            item: controller.searchedProduct[index], index: index),
      );
}
