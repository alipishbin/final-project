import 'dart:convert';

import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/pages/customer/customer_home_page/controllers/customer_controller.dart';
import 'package:final_project/src/pages/customer/customer_home_page/models/customer_page_view_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CustomerProductItemView extends GetView<CustomerController> {
  final CustomerPageViewModel item;
  final int index;

  const CustomerProductItemView(
      {required this.item, required this.index, super.key});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.all(8),
        padding: const EdgeInsets.all(12.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Colors.grey.shade100,
        ),
        child: SingleChildScrollView(
          child: Column(
            children: [
              _imageIcon(),
              _manualSpace(height: 8),
              _title(),
              _manualSpace(height: 8),
              _description(),
              _manualSpace(height: 8),
              Text('${item.price} \$'),
              _showColor(index),
              _manualSpace(height: 4),
              _addToCartTButton(),
            ],
          ),
        ),
      );

  Widget _imageIcon() => CircleAvatar(
        radius: 25,
        backgroundImage: item.imagePath != null
            ? MemoryImage(base64Decode(item.imagePath!))
            : null,
        child: item.imagePath == null
            ? const Icon(
                Icons.upload_rounded,
                size: 20,
              )
            : null,
      );

  Widget _title() => Text(
        overflow: TextOverflow.ellipsis,
        item.title,
        style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            backgroundColor: Colors.lightGreenAccent.shade200),
      );

  Widget _description() => Text(
        overflow: TextOverflow.ellipsis,
        item.description,
        style: const TextStyle(color: Colors.black54),
      );

  Widget _showColor(index) => SizedBox(
        height: 40,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: item.colors.length,
          itemBuilder: (context, index) => Icon(
            Icons.circle,
            size: 35,
            color: Color(
              int.parse(item.colors[index], radix: 16),
            ),
          ),
        ),
      );

  Widget _addToCartTButton() => ElevatedButton(
        style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(Colors.red.shade300)),
        onPressed: () {
          controller.addSelectionToCart(item);
        },
        child: Text(
          LocaleKeys.Add_to_card.tr,
          style: const TextStyle(fontSize: 10),
        ),
      );

  Widget _manualSpace({required double height}) => SizedBox(
        height: height,
      );
}
