class CustomerSelectionDto {
  final String id;
  final String sellerId;
  final String customerId;
  final String title;
  final int price;
  final int quantity;
  final int selectedNumber;

  CustomerSelectionDto(
      {required this.id,
      required this.sellerId,
      required this.customerId,
      required this.title,
      required this.price,
      required this.selectedNumber,
      required this.quantity});

  Map<String, dynamic> toJson() => {
        'id': id,
        'sellerId': sellerId,
        'customerId': customerId,
        'title': title,
        'price': price,
        'quantity': quantity,
        'selectedNumber': selectedNumber,
      };
}
