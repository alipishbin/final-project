class CustomerSelectionViewModel {
  final String id;
  final String sellerId;
  final String customerId;
  final String title;
  final int price;
  final int quantity;
  final int selectedNumber;

  CustomerSelectionViewModel({
    required this.id,
    required this.sellerId,
    required this.customerId,
    required this.title,
    required this.price,
    required this.selectedNumber,
    required this.quantity,
  });

  factory CustomerSelectionViewModel.fromJson(
          final Map<String, dynamic> json) =>
      CustomerSelectionViewModel(
          id: json['id'],
          sellerId: json['sellerId'],
          customerId: json['customerId'],
          title: json['title'],
          price: json['price'],
          quantity: json['quantity'],
          selectedNumber: json['selectedNumber']);
}
