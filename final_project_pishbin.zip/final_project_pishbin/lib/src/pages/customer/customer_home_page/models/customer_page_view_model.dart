class CustomerPageViewModel {
  final String id;
  final String sellerId;
  final String title;
  final String description;
  final int price;
  final int quantity;
  final String? imagePath;
  final List colors;

  const CustomerPageViewModel({
    required this.id,
    required this.sellerId,
    required this.title,
    required this.description,
    required this.price,
    required this.quantity,
    this.imagePath,
    required this.colors,
  });

  factory CustomerPageViewModel.fromJson(final Map<String, dynamic> json) =>
      CustomerPageViewModel(
        id: json['id'],
        sellerId: json['sellerId'],
        title: json['title'],
        description: json['description'],
        price: json['price'],
        quantity: json['quantity'],
        imagePath: json['imagePath'],
        colors: json['colors'],
      );
}
