import 'package:final_project/src/pages/customer/customer_home_page/models/customer_page_view_model.dart';
import 'package:final_project/src/pages/customer/customer_home_page/models/customer_selection_view_model.dart';
import 'package:final_project/src/pages/customer/customer_home_page/repositories/customer_repository.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../generated/locales.g.dart';
import '../../../../infrastructure/commons/user_id.dart';
import '../../../../infrastructure/routes/route_names.dart';
import '../models/customer_selections_dto.dart';
import '../views/widgets/slider_filtering_price_for_customer.dart';

class CustomerController extends GetxController {
  final CustomerRepository _repository = CustomerRepository();

  final TextEditingController searchTextController = TextEditingController();
  final RxBool isLoadingFetchingProductInfo = false.obs;
  final RxBool isLoadingFetchingSelectionByCustomer = false.obs;
  final RxList<CustomerPageViewModel> products = <CustomerPageViewModel>[].obs;

  RxBool isLoadingAddProduct = false.obs;
  RxInt counter = RxInt(0);
  List<CustomerSelectionViewModel> selection = [];

  final Rx<RangeValues> currentRangeValues = const RangeValues(0, 0).obs;
  RxInt max = RxInt(0);
  RxInt min = RxInt(0);
  int minFilter = 0;
  int maxFilter = 0;

  RxList<CustomerPageViewModel> searchedProduct =
      RxList<CustomerPageViewModel>([]);

  @override
  void onInit() {
    super.onInit();
    getPrice();
    getProductList();
    searchedProduct.value = products;
    getSelectionByCustomer();
  }

  Future<void> getProductList() async {
    isLoadingFetchingProductInfo.value = true;
    final result =
        await _repository.fetchAndDisplayActiveProducts(minFilter, maxFilter);
    isLoadingFetchingProductInfo.value = false;

    result.fold(
      (left) {
        Get.showSnackbar(
          GetSnackBar(
            message: 'Error. status code: $left',
          ),
        );
      },
      (right) {
        products.addAll(right);
        searchProducts(searchTextController.text);
      },
    );
  }

  Future<void> getSelectionByCustomer() async {
    isLoadingFetchingSelectionByCustomer.value = true;
    final result = await _repository.fetchSelectionListByCustomerId();
    isLoadingFetchingSelectionByCustomer.value = false;
    result.fold((left) {
      Get.showSnackbar(
        GetSnackBar(
          message: 'Error. status code: $left',
        ),
      );
    }, (right) {
      selection.clear();
      selection.addAll(right);
      counter.value = 0;
      for (final item in right) {
        counter.value += item.selectedNumber;
      }
    });
  }

  Future<void> addSelectionToCart(CustomerPageViewModel item) async {
    for (final item1 in selection) {
      if (item1.id == item.id) {
        return;
      }
    }
    isLoadingAddProduct.value = true;
    final result = await _repository.addSelectionByCustomer(
        model: _customerSelectionDto(item));
    isLoadingAddProduct.value = false;

    result.fold((left) {
      Get.showSnackbar(
        GetSnackBar(
          message: left,
          duration: const Duration(seconds: 2),
        ),
      );
    }, (right) {
      Get.snackbar(LocaleKeys.Done.tr, LocaleKeys.Product_added_to_cart.tr);
      getSelectionByCustomer();
    });
  }

  CustomerSelectionDto _customerSelectionDto(CustomerPageViewModel item) =>
      CustomerSelectionDto(
          id: item.id,
          sellerId: item.sellerId,
          customerId: UserInfo.userId,
          title: item.title,
          price: item.price,
          quantity: item.quantity,
          selectedNumber: 1);

  void onLogOutTapped() {
    Get.offAllNamed(RouteNames.loginPageRoute);
  }

  Future<void> onCartTapped() async {
    await Get.toNamed(
        '${RouteNames.customerHomePageRoute}${RouteNames.customerShoppingCartRoute}');
    getSelectionByCustomer();
    products.clear();
    searchedProduct.clear();
    getProductList();
  }

  void searchProducts(String search) {
    List<CustomerPageViewModel> result = [];
    if (search.isEmpty) {
      result.addAll(products);
    } else {
      result = products
          .where((element) =>
              element.title
                  .toString()
                  .toLowerCase()
                  .contains(search.toLowerCase()) ||
              element.description
                  .toString()
                  .toLowerCase()
                  .contains(search.toLowerCase()))
          .toList();
    }
    searchedProduct.value = result;
  }

  void onClearSearchBarTap() {
    searchTextController.clear();
    searchProducts(searchTextController.text);
  }

  Future<void> getPrice() async {
    final result = await _repository.fetchProductListByPrice();
    result.fold(
      (left) {
        Get.showSnackbar(
          GetSnackBar(
            message: 'Error. status code: $left',
          ),
        );
      },
      (right) {
        if (right.isNotEmpty) {
          min.value = right[0].price;
          max.value = right[right.length - 1].price;
          currentRangeValues.value =
              RangeValues(min.value.toDouble(), max.value.toDouble());
        } else {
          min.value = 0;
          max.value = 1000;
        }
      },
    );
  }

  void openDialog() {
    Get.dialog(
      AlertDialog(
        title: Text(LocaleKeys.Filters.tr),
        content: Text(LocaleKeys.filter_by_price.tr),
        actions: [
          const SliderFilteringPriceForCustomer(),
          TextButton(
            child: Column(
              children: [
                Obx(() {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(currentRangeValues.value.start.round().toString()),
                      Text(currentRangeValues.value.end.round().toString())
                    ],
                  );
                }),
                Text(LocaleKeys.filter.tr),
              ],
            ),
            onPressed: () {
              minFilter = currentRangeValues.value.start.round();
              maxFilter = currentRangeValues.value.end.round();
              products.clear();
              getProductList();
              Get.back();
            },
          ),
        ],
      ),
    );
  }
}
