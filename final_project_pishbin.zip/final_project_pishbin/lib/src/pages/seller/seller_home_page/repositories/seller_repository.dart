import 'dart:convert';

import 'package:either_dart/either.dart';
import 'package:final_project/src/infrastructure/commons/user_id.dart';
import 'package:http/http.dart' as http;

import '../../../../infrastructure/commons/repository_urls.dart';
import '../models/seller_page_view_model.dart';

class SellerRepository {
  Future<Either<String, List<SellerPageViewModel>>> fetchProductList(
      int min, int max) async {
    if (min == 0 && max == 0) {
      try {
        await Future.delayed(const Duration(seconds: 1));

        var url = Uri.http(
          RepositoryUrls.webBaseUrl,
          RepositoryUrls.products, //404
          {
            'sellerId': UserInfo.userId,
          },
        );
        final response = await http.get(url);
        if (response.statusCode >= 200 && response.statusCode < 400) {
          final List<dynamic> products = jsonDecode(response.body);
          final List<SellerPageViewModel> listOfProducts = [];
          for (var item in products) {
            final productModel = SellerPageViewModel.fromJson(item);
            listOfProducts.add(productModel);
          }
          return Right(listOfProducts);
        } else {
          return Left('${response.statusCode}');
        }
      } catch (error) {
        return Left('$error');
      }
    } else {
      try {
        await Future.delayed(const Duration(seconds: 1));

        var url = Uri.http(
          RepositoryUrls.webBaseUrl,
          RepositoryUrls.products,
          {
            'sellerId': UserInfo.userId,
          },
        );
        final response = await http.get(url);
        if (response.statusCode >= 200 && response.statusCode < 400) {
          final List<dynamic> products = jsonDecode(response.body);
          final List<dynamic> sellerProductJson = products
              .where((element) =>
                  element['price'] >= min && element['price'] <= max)
              .toList();
          final List<SellerPageViewModel> listOfProductsForFilter = [];

          for (var item in sellerProductJson) {
            final productModel = SellerPageViewModel.fromJson(item);
            listOfProductsForFilter.add(productModel);
          }
          return Right(listOfProductsForFilter);
        } else {
          return Left('${response.statusCode}');
        }
      } catch (error) {
        return Left('$error');
      }
    }
  }

  Future<Either<String, List<SellerPageViewModel>>>
      fetchingProductListByPrice() async {
    try {
      await Future.delayed(const Duration(seconds: 1));

      var url = Uri.http(RepositoryUrls.webBaseUrl, RepositoryUrls.products, {
        'sellerId': UserInfo.userId,
        '_sort': 'price',
      });
      final response = await http.get(url);
      if (response.statusCode >= 200 && response.statusCode < 400) {
        final List<dynamic> products = jsonDecode(response.body);
        final List<SellerPageViewModel> listOfProducts = [];
        for (var item in products) {
          final productModel = SellerPageViewModel.fromJson(item);
          listOfProducts.add(productModel);
        }
        return Right(listOfProducts);
      } else {
        return Left('${response.statusCode}');
      }
    } catch (error) {
      return Left('$error');
    }
  }
}
