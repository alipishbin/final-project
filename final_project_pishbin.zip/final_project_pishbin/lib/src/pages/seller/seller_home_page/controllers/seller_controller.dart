import 'package:either_dart/either.dart';
import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/infrastructure/routes/route_names.dart';
import 'package:final_project/src/pages/seller/seller_home_page/models/seller_page_view_model.dart';
import 'package:final_project/src/pages/seller/seller_home_page/repositories/seller_repository.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../views/widgets/slider_filtering_price_for_seller.dart';

class SellerHomeController extends GetxController {
  final SellerRepository _repository = SellerRepository();
  final TextEditingController searchTextController = TextEditingController();

  final RxBool isLoadingFetchingProductInfo = false.obs;
  final RxList<SellerPageViewModel> products = <SellerPageViewModel>[].obs;

  final Rx<RangeValues> currentRangeValues = const RangeValues(0, 0).obs;
  RxInt max = RxInt(0);
  RxInt min = RxInt(0);
  int minFilter = 0;
  int maxFilter = 0;

  RxList<SellerPageViewModel> searchedProduct = RxList<SellerPageViewModel>([]);

  @override
  void onInit() {
    super.onInit();
    getPrice();
    getProductList();
    searchedProduct.value = products;
    searchProducts(searchTextController.text);
  }

  void getProductList() async {
    products.clear();
    isLoadingFetchingProductInfo.value = true;
    final Either<String, List<SellerPageViewModel>> result =
        await _repository.fetchProductList(minFilter, maxFilter);
    result.fold(
      (left) {
        isLoadingFetchingProductInfo.value = false;
        Get.showSnackbar(
          GetSnackBar(
            message: 'Error. status code: $left',
          ),
        );
      },
      (right) {
        isLoadingFetchingProductInfo.value = false;
        products.addAll(right);
        searchProducts(searchTextController.text);
      },
    );
  }

  void addProductButton() async {
    await Get.toNamed(
      '${RouteNames.sellerPageRoute}${RouteNames.sellerAddProductPageRoute}',
    );
    getProductList();
    getPrice();
  }

  void onLogOutTapped() {
    Get.offAllNamed(RouteNames.loginPageRoute);
  }

  void searchProducts(String search) {
    List<SellerPageViewModel> result = [];
    if (search.isEmpty) {
      result.addAll(products);
    } else {
      result = products
          .where((element) =>
              element.title
                  .toString()
                  .toLowerCase()
                  .contains(search.toLowerCase()) ||
              element.description
                  .toString()
                  .toLowerCase()
                  .contains(search.toLowerCase()))
          .toList();
    }
    searchedProduct.value = result;
  }

  void onClearSearchBarTap() {
    searchTextController.clear();
    searchProducts(searchTextController.text);
  }

  Future<void> getPrice() async {
    final result = await _repository.fetchingProductListByPrice();
    result.fold(
      (left) {
        Get.showSnackbar(
          GetSnackBar(
            message: 'Error. status code: $left',
          ),
        );
      },
      (right) {
        if (right.isNotEmpty) {
          min.value = right[0].price;
          max.value = right[right.length - 1].price;
          currentRangeValues.value =
              RangeValues(min.value.toDouble(), max.value.toDouble());
        } else {
          min.value = 0;
          max.value = 1000;
        }
      },
    );
  }

  void openDialog() {
    Get.dialog(
      AlertDialog(
        title: Text(LocaleKeys.Filters.tr),
        content: Text(LocaleKeys.filter_by_price.tr),
        actions: [
          const SliderFilteringPriceForSeller(),
          TextButton(
            child: Column(
              children: [
                Obx(() {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(currentRangeValues.value.start.round().toString()),
                      Text(currentRangeValues.value.end.round().toString())
                    ],
                  );
                }),
                Text(LocaleKeys.filter.tr),
              ],
            ),
            onPressed: () {
              minFilter = currentRangeValues.value.start.round();
              maxFilter = currentRangeValues.value.end.round();
              products.clear();
              getProductList();
              Get.back();
            },
          ),
        ],
      ),
    );
  }
}
