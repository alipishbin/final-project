import 'package:final_project/src/pages/seller/seller_home_page/controllers/seller_controller.dart';
import 'package:get/get.dart';

class SellerBindings extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SellerHomeController());
  }
}
