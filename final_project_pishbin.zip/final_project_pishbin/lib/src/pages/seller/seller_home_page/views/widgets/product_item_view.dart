import 'dart:convert';

import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/infrastructure/routes/route_names.dart';
import 'package:final_project/src/pages/seller/seller_home_page/controllers/seller_controller.dart';
import 'package:final_project/src/pages/seller/seller_home_page/models/seller_page_view_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ProductItemView extends GetView<SellerHomeController> {
  final SellerPageViewModel item;
  final int index;

  const ProductItemView({required this.item, required this.index, super.key});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.all(8),
        padding: const EdgeInsets.all(12.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Colors.grey.shade100,
          border: Border.all(
              color: item.isActive == true && item.quantity > 0
                  ? Colors.green
                  : Colors.red,
              width: 3),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _imageStatusAndEdit(),
            _title(),
            _description(),
            _priceAndCount(),
            _showColor(index),
          ],
        ),
      );

  Widget _imageStatusAndEdit() => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [_statusText(), _imageIcon(), _editProduct()],
      );

  Widget _statusText() => Text(
        item.isActive == true && item.quantity > 0
            ? LocaleKeys.available.tr
            : LocaleKeys.unavailable.tr,
        style: const TextStyle(fontSize: 12),
      );

  Widget _imageIcon() => CircleAvatar(
        radius: 25,
        backgroundImage: item.imagePath != null
            ? MemoryImage(base64Decode(item.imagePath!))
            : null,
        child: item.imagePath == null
            ? const Icon(
                Icons.upload_rounded,
                size: 25,
              )
            : null,
      );

  Widget _editProduct() => IconButton(
        onPressed: () async {
          await Get.toNamed(
              '${RouteNames.sellerPageRoute}${RouteNames.sellerEditProductPageRoute}',
              arguments: item.id);
          controller.getProductList();
        },
        icon: const Icon(Icons.edit),
        color: Colors.red,
      );

  Widget _description() => Text(
        overflow: TextOverflow.ellipsis,
        item.description,
        style: const TextStyle(color: Colors.black54),
      );

  Widget _title() {
    return Text(
      overflow: TextOverflow.ellipsis,
      item.title,
      style: const TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 18,
        // backgroundColor: Colors.amberAccent),
      ),
    );
  }

  Widget _priceAndCount() => Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              '${item.price} \$',
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    '${item.quantity} ',
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const Icon(Icons.assignment_turned_in),
              ],
            ),
          ),
        ],
      );

  Widget _showColor(index) => SizedBox(
        height: 40,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: item.colors.length,
          itemBuilder: (context, index) => Icon(
            Icons.circle,
            size: 35,
            color: Color(
              int.parse(item.colors[index], radix: 16),
            ),
          ),
        ),
      );
}
