import 'package:final_project/src/pages/seller/seller_home_page/controllers/seller_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SliderFilteringPriceForSeller extends GetView<SellerHomeController> {
  const SliderFilteringPriceForSeller({super.key});

  @override
  Widget build(BuildContext context) => Obx(() {
        return RangeSlider(
          values: controller.currentRangeValues.value,
          max: controller.max.value.toDouble(),
          min: controller.min.value.toDouble(),
          onChanged: (RangeValues values) {
            controller.currentRangeValues.value = values;
          },
        );
      });
}
