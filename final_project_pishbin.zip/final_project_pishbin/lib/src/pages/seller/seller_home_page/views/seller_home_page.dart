import 'package:custom_search/custom_search.dart';
import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/pages/seller/seller_home_page/controllers/seller_controller.dart';
import 'package:final_project/src/pages/seller/seller_home_page/views/widgets/product_item_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SellerHomePage extends GetView<SellerHomeController> {
  const SellerHomePage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: _appBar(context),
        floatingActionButton: Align(
          alignment: Alignment.bottomCenter,
          child: FloatingActionButton(
            onPressed: () => controller.addProductButton(),
            backgroundColor: Colors.indigoAccent.shade100,
            child: const Icon(Icons.add),
          ),
        ),
        body: _buildBody(context),
      );

  AppBar _appBar(context) => AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(LocaleKeys.Seller_home_page.tr),
            SizedBox(
              width: MediaQuery.of(context).size.width * .3,
            ),
            IconButton(
              onPressed: () => controller.onLogOutTapped(),
              icon: const Icon(Icons.logout),
            ),
          ],
        ),
        backgroundColor: Colors.orange.shade200,
      );

  Widget _buildBody(BuildContext context) => Obx(() {
        return controller.isLoadingFetchingProductInfo.value
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * .9,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.orange,
                      width: 2,
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    children: [
                      _packageCustomSearchBar(),
                      Expanded(child: _gridProductItems()),
                    ],
                  ),
                ),
              );
      });

  Widget _packageCustomSearchBar() {
    return CustomSearchBar(
      onSearchTextFieldChanged: (value) => controller.searchProducts(value),
      onClearSearchTap: () => controller.onClearSearchBarTap(),
      onFilterButtonTap: () => controller.openDialog(),
      searchTextController: controller.searchTextController,
    );
  }

  Widget _gridProductItems() => GridView.builder(
        gridDelegate:
            const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemCount: controller.searchedProduct.length,
        itemBuilder: (context, index) => ProductItemView(
            item: controller.searchedProduct[index], index: index),
      );
}
