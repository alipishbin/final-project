class SellerPageViewModel {
  final String id;
  final String title;
  final String description;
  final int price;
  final int quantity;
  final bool isActive;
  final String? imagePath;
  final String? sellerId;
  final List colors;

  const SellerPageViewModel(
      {required this.id,
      required this.title,
      required this.description,
      required this.price,
      required this.quantity,
      required this.isActive,
      this.imagePath,
      this.sellerId,
      required this.colors});

  factory SellerPageViewModel.fromJson(final Map<String, dynamic> json) =>
      SellerPageViewModel(
        id: json['id'],
        title: json['title'],
        description: json['description'],
        price: json['price'],
        quantity: json['quantity'],
        isActive: json['isActive'],
        imagePath: json['imagePath'],
        sellerId: json['sellerId'],
        colors: json['colors'],
      );
}
