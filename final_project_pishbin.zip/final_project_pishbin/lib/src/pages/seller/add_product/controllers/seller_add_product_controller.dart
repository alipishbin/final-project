import 'dart:convert';

import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/infrastructure/commons/user_id.dart';
import 'package:final_project/src/pages/seller/add_product/models/add_product_dto.dart';
import 'package:final_project/src/pages/seller/add_product/repositories/seller_add_product_repository.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../infrastructure/routes/route_names.dart';

class SellerAddProductController extends GetxController {
  final SellerAddProductRepository _repository = SellerAddProductRepository();
  TextEditingController titleTextController = TextEditingController(),
      descriptionTextController = TextEditingController(),
      priceTextController = TextEditingController(),
      quantityTextController = TextEditingController();

  GlobalKey<FormState> formKey = GlobalKey();
  RxBool isLoadingAddProduct = false.obs;
  RxBool isActive = false.obs;

  RxnString imageToString = RxnString();

  Rx<Color> pickedColor = Rx<Color>(Colors.blue);
  RxList<String> colors = RxList();

  @override
  void onClose() {
    super.onClose();
    titleTextController.clear();
    descriptionTextController.clear();
    priceTextController.clear();
    quantityTextController.clear();
  }

  Future<void> submitAddingProduct() async {
    if (!(formKey.currentState?.validate() ?? false)) {
      return;
    }
    isLoadingAddProduct.value = true;
    final result =
        await _repository.addProductBySeller(model: _addProductDto());
    isLoadingAddProduct.value = false;
    result.fold((left) {
      Get.showSnackbar(
        GetSnackBar(
          message: left,
          duration: const Duration(seconds: 1),
        ),
      );
    }, (right) {
      Get.snackbar(
          LocaleKeys.Well_Done.tr, LocaleKeys.Product_successfully_added.tr);
      Get.offNamed(RouteNames.sellerPageRoute);
      // Get.back(result: right);
    });
  }

  AddProductDto _addProductDto() => AddProductDto(
      title: titleTextController.text.trim(),
      description: descriptionTextController.text.trim(),
      price: int.parse(priceTextController.text.trim()),
      quantity: int.parse(quantityTextController.text.trim()),
      isActive: isActive.value,
      imagePath: imageToString.value,
      sellerId: UserInfo.userId,
      colors: colors);

  void toggle() => isActive.value = isActive.value ? false : true;

  Future<void> onImageSelectionTapped() async {
    final picker = ImagePicker();
    final imagePicked = await picker.pickImage(source: ImageSource.gallery);
    if (imagePicked != null) {
      List<int> imageBytes = await imagePicked.readAsBytes();
      imageToString.value = base64Encode(imageBytes);
    } else {
      Get.showSnackbar(GetSnackBar(
        message: LocaleKeys.No_image_selected.tr,
        backgroundColor: Colors.blueGrey,
        duration: const Duration(seconds: 3),
      ));
    }
  }

  void onRemoveImageTapped() {
    imageToString.value == null;
  }

  void chooseColor(value) {
    pickedColor.value = value;
  }

  void confirmColorButton() {
    String colorCode =
        pickedColor.value.toString().split('(0x')[1].split(')')[0];
    if (colors.length < 5) {
      colors.add(colorCode);
    }
  }

  void onRemoveColorTapped(index) {
    colors.removeAt(index);
  }
}
