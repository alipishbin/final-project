import 'dart:convert';

import 'package:final_project/generated/locales.g.dart';
import 'package:final_project/src/pages/seller/add_product/controllers/seller_add_product_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:get/get.dart';

class SellerAddProductPage extends GetView<SellerAddProductController> {
  const SellerAddProductPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.orangeAccent,
          title: Center(
            child: Text(LocaleKeys.Adding_product.tr),
          ),
        ),
        body: _buildBody(context),
      );

  Widget _buildBody(BuildContext context) => Center(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width * .9,
          decoration: BoxDecoration(
            border: Border.all(
              color: Colors.orange,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Form(
            key: controller.formKey,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Column(
                    children: [
                      _imagePicker(),
                      _title(),
                      _description(),
                      _price(),
                      _quantity(),
                    ],
                  ),
                  _manualSpace(height: 12),
                  _colors(),
                  _listOfColors(),
                  _activateStatus(),
                  _manualSpace(height: 12),
                  _submitButton(),
                  _manualSpace(height: 8),
                ],
              ),
            ),
          ),
        ),
      );

  Widget _imagePicker() => InkWell(
        onTap: () async {
          await controller.onImageSelectionTapped();
        },
        child: Obx(() {
          final pickedFile = controller.imageToString.value;
          if (pickedFile != null) {
            return CircleAvatar(
              radius: 50,
              backgroundImage: MemoryImage(base64Decode(pickedFile)),
              child: null,
            );
          } else {
            return const CircleAvatar(
              radius: 50,
              child: Icon(
                Icons.upload_rounded,
                size: 35,
              ),
            );
          }
        }),
      );

  Widget _title() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: TextFormField(
          controller: controller.titleTextController,
          maxLength: 10,
          validator: (value) => value != null && value.isNotEmpty
              ? null
              : LocaleKeys.The_title_cannot_be_empty.tr,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          decoration: InputDecoration(label: Text(LocaleKeys.insert_title.tr)),
        ),
      );

  Widget _description() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: TextFormField(
          controller: controller.descriptionTextController,
          maxLength: 15,
          validator: (value) => value != null && value.isNotEmpty
              ? null
              : LocaleKeys.The_description_cannot_be_empty.tr,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          maxLines: 3,
          decoration:
              InputDecoration(label: Text(LocaleKeys.insert_description.tr)),
        ),
      );

  Widget _price() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: TextFormField(
          controller: controller.priceTextController,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          validator: (value) => value != null && value.isNotEmpty
              ? null
              : LocaleKeys.The_price_cannot_be_empty.tr,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          decoration: InputDecoration(label: Text(LocaleKeys.insert_price.tr)),
        ),
      );

  Widget _quantity() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: TextFormField(
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          controller: controller.quantityTextController,
          validator: (value) => value != null && value.isNotEmpty
              ? null
              : LocaleKeys.The_quantity_cannot_be_empty.tr,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          decoration:
              InputDecoration(label: Text(LocaleKeys.insert_quantity.tr)),
        ),
      );

  Widget _submitButton() => Obx(() {
        return controller.isLoadingAddProduct.value
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.lightGreen,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                ),
                onPressed: () => controller.submitAddingProduct(),
                child: Center(
                  child: Text(
                    LocaleKeys.submit.tr,
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              );
      });

  Widget _switchButton() => Switch(
        value: controller.isActive.value,
        onChanged: (value) => controller.toggle(),
      );

  Widget _activateStatus() => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            LocaleKeys.Activation_Status.tr,
            style: TextStyle(
                fontWeight: FontWeight.bold,
                backgroundColor: Colors.purple.shade100),
          ),
          Obx(() {
            return _switchButton();
          })
        ],
      );

  Widget _manualSpace({required double height}) => SizedBox(
        height: height,
      );

  Widget _colors() => ElevatedButton(
        onPressed: () {
          Get.defaultDialog(
            title: LocaleKeys.color.tr,
            content: ColorPicker(
              pickerColor: controller.pickedColor.value,
              onColorChanged: (value) => controller.chooseColor(value),
            ),
            actions: [
              TextButton(
                  style: const ButtonStyle(alignment: Alignment.center),
                  onPressed: () {
                    controller.confirmColorButton();
                    Get.back();
                  },
                  child: Text(LocaleKeys.ok.tr))
            ],
          );
        },
        child: Text(LocaleKeys.color.tr),
      );

  Widget _colorInList(int index) => Stack(
        children: [
          Icon(
            Icons.circle,
            size: 35,
            color: Color(
              int.parse(controller.colors[index], radix: 16),
            ),
          ),
          Positioned(
            bottom: 20,
            left: 20,
            child: InkWell(
              child: const Icon(
                Icons.remove,
                color: Colors.red,
              ),
              onTap: () => controller.onRemoveColorTapped(index),
            ),
          )
        ],
      );

  Widget _listOfColors() => Obx(() {
        return SizedBox(
          height: 40,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: controller.colors.length,
            itemBuilder: (context, index) => _colorInList(index),
          ),
        );
      });
}
