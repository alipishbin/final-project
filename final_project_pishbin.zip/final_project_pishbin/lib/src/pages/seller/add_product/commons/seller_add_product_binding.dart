import 'package:final_project/src/pages/seller/add_product/controllers/seller_add_product_controller.dart';
import 'package:get/get.dart';

class SellerAddProductBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SellerAddProductController());
  }
}
