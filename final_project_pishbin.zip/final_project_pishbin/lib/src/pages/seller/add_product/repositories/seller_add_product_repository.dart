import 'dart:convert';

import 'package:either_dart/either.dart';
import 'package:final_project/src/pages/seller/add_product/models/add_product_dto.dart';
import 'package:http/http.dart' as http;

import '../../../../infrastructure/commons/repository_urls.dart';

class SellerAddProductRepository {
  Future<Either<String, dynamic>> addProductBySeller(
      {required AddProductDto model}) async {
    try {
      await Future.delayed(const Duration(seconds: 1));
      final url = Uri.http(RepositoryUrls.webBaseUrl, RepositoryUrls.products);
      final response = await http.post(
        url,
        body: jsonEncode(model.toJson()),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode >= 200 && response.statusCode < 400) {
        return const Right('success');
      } else {
        return Left("${response.statusCode}");
      }
    } catch (error) {
      return Left(error.toString());
    }
  }
}
