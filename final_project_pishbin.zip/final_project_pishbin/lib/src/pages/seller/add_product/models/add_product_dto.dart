class AddProductDto {
  final String sellerId;
  final String title;
  final String description;
  final int price;
  final int quantity;
  final bool isActive;
  final String? imagePath;
  final List colors;

  const AddProductDto(
      {required this.title,
      required this.description,
      required this.price,
      required this.quantity,
      required this.isActive,
      this.imagePath,
      required this.sellerId,
      required this.colors});

  Map<String, dynamic> toJson() => {
        'sellerId': sellerId,
        'title': title,
        'description': description,
        'price': price,
        'quantity': quantity,
        'isActive': isActive,
        'imagePath': imagePath,
        'colors': colors,
      };
}
