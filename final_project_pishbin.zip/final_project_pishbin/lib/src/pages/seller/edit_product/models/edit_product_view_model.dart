class EditProductViewModel {
  final String sellerId;
  final String id;
  final String title;
  final String description;
  final int price;
  final int quantity;
  final bool isActive;
  final String? imagePath;
  final List colors;

  const EditProductViewModel(
      {required this.title,
      required this.sellerId,
      required this.id,
      required this.description,
      required this.price,
      required this.quantity,
      required this.isActive,
      required this.colors,
      this.imagePath});

  factory EditProductViewModel.fromJson(final Map<String, dynamic> json) =>
      EditProductViewModel(
          id: json['id'],
          sellerId: json['sellerId'],
          title: json['title'],
          description: json['description'],
          price: json['price'],
          quantity: json['quantity'],
          isActive: json['isActive'],
          imagePath: json['imagePath'],
          colors: json['colors']);
}
