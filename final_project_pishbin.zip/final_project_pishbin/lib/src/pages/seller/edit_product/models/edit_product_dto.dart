class EditProductDto {
  final String id;
  final String sellerId;
  final String title;
  final String description;
  final int price;
  final int quantity;
  final bool isActive;
  final String? imagePath;
  final List colors;

  const EditProductDto(
      {required this.title,
      required this.sellerId,
      required this.id,
      required this.description,
      required this.price,
      required this.quantity,
      required this.isActive,
      required this.colors,
      this.imagePath});

  Map<String, dynamic> toJson() => {
        'id': id,
        'sellerId': sellerId,
        'title': title,
        'description': description,
        'price': price,
        'quantity': quantity,
        'isActive': isActive,
        'imagePath': imagePath,
        'colors': colors,
      };
}
