import 'package:get/get.dart';

import '../controllers/seller_edit_product_controller.dart';

class SellerEditProductsBinding extends Bindings {
  @override
  void dependencies() {
    String id = Get.arguments;
    Get.lazyPut(() => SellerEditProductController(id));
  }
}
