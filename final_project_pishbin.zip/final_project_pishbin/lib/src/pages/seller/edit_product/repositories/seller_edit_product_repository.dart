import 'dart:convert';

import 'package:either_dart/either.dart';
import 'package:final_project/src/pages/seller/edit_product/models/edit_product_dto.dart';
import 'package:final_project/src/pages/seller/edit_product/models/edit_product_view_model.dart';
import 'package:http/http.dart' as http;

import '../../../../infrastructure/commons/repository_urls.dart';

class SellerEditProductRepository {
  Future<Either<String, EditProductViewModel>> fetchingProductInfo(
      String id) async {
    try {
      await Future.delayed(const Duration(seconds: 1));

      var url = Uri.http(
        RepositoryUrls.webBaseUrl,
        RepositoryUrls.editProduct(id),
      );
      final response = await http.get(url);
      if (response.statusCode >= 200 && response.statusCode < 400) {
        final products = jsonDecode(response.body);
        final productModel = EditProductViewModel.fromJson(products);
        return Right(productModel);
      } else {
        return Left('${response.statusCode}');
      }
    } catch (error) {
      return Left('$error');
    }
  }

  Future<Either<String, EditProductViewModel>> changeProductInfo(
      {required EditProductDto dto}) async {
    try {
      await Future.delayed(const Duration(seconds: 2));
      final url = Uri.http(
          RepositoryUrls.webBaseUrl, RepositoryUrls.editProduct(dto.id));

      final response = await http.put(
        url,
        body: jsonEncode(dto.toJson()),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode >= 200 && response.statusCode < 400) {
        final Map<String, dynamic> json = jsonDecode(response.body);
        final EditProductViewModel editProducts =
            EditProductViewModel.fromJson(json);
        return Right(editProducts);
      } else {
        return Left('${response.statusCode}');
      }
    } catch (error) {
      return Left('$error');
    }
  }
}
