import 'dart:convert';

import 'package:final_project/src/pages/seller/edit_product/models/edit_product_dto.dart';
import 'package:final_project/src/pages/seller/edit_product/models/edit_product_view_model.dart';
import 'package:final_project/src/pages/seller/edit_product/repositories/seller_edit_product_repository.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../infrastructure/routes/route_names.dart';

class SellerEditProductController extends GetxController {
  String id;
  SellerEditProductController(this.id);

  final SellerEditProductRepository _repository = SellerEditProductRepository();

  TextEditingController titleTextController = TextEditingController(),
      descriptionTextController = TextEditingController(),
      priceTextController = TextEditingController(),
      quantityTextController = TextEditingController();

  RxBool isLoadingEditProduct = false.obs;
  RxMap<String, bool> isLoadingEditMap = RxMap();
  RxList<EditProductViewModel> productsList = RxList();
  RxBool isActive = false.obs;

  RxnString imagePath = RxnString();
  RxString sellerId = RxString('');
  GlobalKey<FormState> formKey = GlobalKey();
  RxList<String> colors = RxList();
  Rx<Color> pickedColor = Rx<Color>(Colors.white30);

  @override
  void onInit() {
    super.onInit();
    getProduct();
  }

  void getProduct() async {
    final result = await _repository.fetchingProductInfo(id);
    result.fold((left) {
      Get.showSnackbar(
        GetSnackBar(
          message: 'Error. status code: $left',
        ),
      );
    }, (right) {
      titleTextController.text = right.title;
      descriptionTextController.text = right.description;
      priceTextController.text = right.price.toString();
      quantityTextController.text = right.quantity.toString();
      imagePath.value = right.imagePath;
      isActive.value = right.isActive;
      sellerId.value = right.sellerId;
      for (final item in right.colors) {
        colors.add(item);
      }
    });
  }

  Future<void> editProduct() async {
    if (!(formKey.currentState?.validate() ?? false)) {
      return;
    }
    isLoadingEditProduct.value = true;

    final EditProductDto dto = EditProductDto(
      title: titleTextController.text,
      id: id,
      description: descriptionTextController.text,
      price: int.parse(priceTextController.text),
      quantity: int.parse(quantityTextController.text),
      isActive: isActive.value,
      imagePath: imagePath.value,
      sellerId: sellerId.value,
      colors: colors,
    );

    final result = await _repository.changeProductInfo(dto: dto);
    isLoadingEditProduct.value = false;

    result.fold(
      (left) {
        Get.showSnackbar(
          GetSnackBar(
            title: left,
          ),
        );
      },
      (right) {
        Get.offNamed(RouteNames.sellerPageRoute);
      },
    );
  }

  Future<void> onImageSelectionTapped() async {
    final picker = ImagePicker();
    final imagePicked = await picker.pickImage(source: ImageSource.gallery);
    if (imagePicked != null) {
      List<int> imageBytes = await imagePicked.readAsBytes();
      imagePath.value = base64Encode(imageBytes);
    } else {
      Get.showSnackbar(const GetSnackBar(
        message: 'No image selected',
        duration: Duration(seconds: 3),
      ));
    }
  }

  void toggle() => isActive.value = !isActive.value;

  void chooseColor(value) {
    pickedColor.value = value;
  }

  void confirmColorButton() {
    String colorCode =
        pickedColor.value.toString().split('(0x')[1].split(')')[0];
    if (colors.length < 5) {
      colors.add(colorCode);
    }
  }

  void onRemoveColorTapped(index) {
    colors.removeAt(index);
  }
}
