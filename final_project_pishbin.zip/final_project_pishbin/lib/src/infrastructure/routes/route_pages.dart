import 'package:final_project/src/infrastructure/routes/route_names.dart';
import 'package:final_project/src/pages/customer/customer_home_page/commons/customer_binding.dart';
import 'package:final_project/src/pages/customer/customer_home_page/views/customer_home_page.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/commons/customer_shopping_binding.dart';
import 'package:final_project/src/pages/customer/customers_shopping_cart/views/customer_shopping_cart_page.dart';
import 'package:final_project/src/pages/login/views/login_page.dart';
import 'package:final_project/src/pages/seller/add_product/commons/seller_add_product_binding.dart';
import 'package:final_project/src/pages/seller/add_product/views/seller_add_product_page.dart';
import 'package:final_project/src/pages/seller/edit_product/commons/seller_edit_product_binding.dart';
import 'package:final_project/src/pages/seller/edit_product/views/seller_edit_product_page.dart';
import 'package:final_project/src/pages/seller/seller_home_page/commons/seller_bindings.dart';
import 'package:final_project/src/pages/seller/seller_home_page/views/seller_home_page.dart';
import 'package:final_project/src/pages/sign_up/commons/sign_up_binding.dart';
import 'package:final_project/src/pages/sign_up/views/sign_up_page.dart';
import 'package:get/get.dart';

import '../../pages/login/commons/login_binding.dart';

class RoutePages {
  static List<GetPage> getPages = [
    GetPage(
      name: RouteNames.loginPageRoute,
      page: () => const LoginPage(),
      binding: LoginBinding(),
      children: [
        GetPage(
          name: RouteNames.singUpPageRoute,
          page: () => const SignUpPage(),
          binding: SignUpBinding(),
        ),
      ],
    ),
    GetPage(
      name: RouteNames.sellerPageRoute,
      page: () => const SellerHomePage(),
      binding: SellerBindings(),
      children: [
        GetPage(
          name: RouteNames.sellerAddProductPageRoute,
          page: () => const SellerAddProductPage(),
          binding: SellerAddProductBinding(),
        ),
        GetPage(
          name: RouteNames.sellerEditProductPageRoute,
          page: () => const SellerEditProductPage(),
          binding: SellerEditProductsBinding(),
        ),
      ],
    ),
    GetPage(
      name: RouteNames.customerHomePageRoute,
      page: () => const CustomerHomePage(),
      binding: CustomerBinding(),
      children: [
        GetPage(
          name: RouteNames.customerShoppingCartRoute,
          page: () => const CustomerShoppingCartPage(),
          binding: CustomerShoppingBinding(),
        ),
      ],
    ),
  ];
}
