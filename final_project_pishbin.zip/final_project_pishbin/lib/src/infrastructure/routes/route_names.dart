class RouteNames {
  static const String loginPageRoute = "/login";
  static const String singUpPageRoute = "/sign-up";

  // ************** seller ******************************
  static const String sellerPageRoute = "/seller-home";
  static const String sellerAddProductPageRoute = "/seller-add-product";
  static const String sellerEditProductPageRoute = "/seller-edit-product";

  // ************** customer ****************************
  static const String customerHomePageRoute = "/customer-home";
  static const String customerShoppingCartRoute = "/customer-shopping-cart";
}
