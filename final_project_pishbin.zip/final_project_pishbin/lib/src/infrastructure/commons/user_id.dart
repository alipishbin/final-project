class UserInfo {
  static String userId = '';
}
