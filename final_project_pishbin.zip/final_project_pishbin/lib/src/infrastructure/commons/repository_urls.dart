class RepositoryUrls {
  static const String webBaseUrl = '127.0.0.1:3000';
  static const String users = '/user';
  static const String products = '/product';
  static String editProduct(String id) => '/product/$id';
  static String editSelection(String id) => '/selections/$id';
  static const String selections = '/selections';
}
