import 'package:flutter/material.dart';

class CustomNumberPicker extends StatefulWidget {
  const CustomNumberPicker(
      {required this.initialValue,
      required this.minValue,
      required this.maxValue,
      required this.onIncrease,
      required this.onDecrease,
      super.key})
      : assert(minValue <= maxValue),
        assert(initialValue >= minValue && initialValue <= maxValue);

  final int initialValue;
  final int minValue;
  final int maxValue;
  final void Function(int) onIncrease;
  final void Function(int) onDecrease;

  @override
  State<CustomNumberPicker> createState() => _CustomNumberPickerState();
}

class _CustomNumberPickerState extends State<CustomNumberPicker> {
  late int value;

  @override
  void initState() {
    super.initState();
    value = widget.initialValue;
  }

  @override
  Widget build(BuildContext context) => Row(
        children: [
          IconButton(
              onPressed: () => decrement(),
              icon: const Icon(Icons.arrow_back_ios_sharp)),
          Text('$value'),
          IconButton(
              onPressed: () => increment(),
              icon: const Icon(Icons.arrow_forward_ios_sharp))
        ],
      );

  void increment() {
    if (value + 1 <= widget.maxValue) {
      setState(() {
        value++;
      });
      widget.onIncrease.call(value);
    }
  }

  void decrement() {
    if (value - 1 >= widget.minValue) {
      setState(() {
        value--;
      });
      widget.onDecrease.call(value);
    }
  }
}
