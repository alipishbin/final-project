// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

// ignore_for_file: lines_longer_than_80_chars
// ignore: avoid_classes_with_only_static_members
import 'package:get/get.dart';

class AppTranslation extends Translations {
  // static Map<String, Map<String, String>> translations = {
  //   'en_US': Locales.en_US,
  //   'fa_IR': Locales.fa_IR,
  // };

  @override
  // TODO: implement keys
  Map<String, Map<String, String>> get keys => {
        'en_US': Locales.en_US,
        'fa_IR': Locales.fa_IR,
      };
}

class LocaleKeys {
  LocaleKeys._();
  static const Seller_home_page = 'Seller_home_page';
  static const Customer_home_page = 'Customer_home_page';
  static const Login = 'Login';
  static const sign_up = 'sign_up';
  static const Remember_me = 'Remember_me';
  static const password = 'password';
  static const Add_to_cart = 'Add_to_cart';
  static const log_in_to_enter_the_shop = 'log_in_to_enter_the_shop';
  static const username = 'username';
  static const To_sell_or_buy_a_product_you_will_need_a_free_account =
      'To_sell_or_buy_a_product_you_will_need_a_free_account';
  static const username_cannot_be_empty = 'username_cannot_be_empty';
  static const Enter_your_username = 'Enter_your_username';
  static const password_cannot_be_empty = 'password_cannot_be_empty';
  static const Enter_your_password = 'Enter_your_password';
  static const Do_not_have_an_account__ = 'Do_not_have_an_account__';
  static const You_must_sign_up_first = 'You_must_sign_up_first';
  static const Enter_your_first_name = 'Enter_your_first_name';
  static const first_name = 'first_name';
  static const first_name_cannot_be_empty = 'first_name_cannot_be_empty';
  static const Enter_your_last_name = 'Enter_your_last_name';
  static const last_name = 'last_name';
  static const last_name_cannot_be_empty = 'last_name_cannot_be_empty';
  static const Repeat_your_password = 'Repeat_your_password';
  static const repeat_password = 'repeat_password';
  static const this_field_cannot_be_empty = 'this_field_cannot_be_empty';
  static const Select_Your_Role = 'Select_Your_Role';
  static const customer = 'customer';
  static const seller = 'seller';
  static const Filters = 'Filters';
  static const filter_by_price = 'filter_by_price';
  static const filter = 'filter';
  static const Adding_product = 'Adding_product';
  static const The_title_cannot_be_empty = 'The_title_cannot_be_empty';
  static const insert_title = 'insert_title';
  static const insert_description = 'insert_description';
  static const The_description_cannot_be_empty =
      'The_description_cannot_be_empty';
  static const The_price_cannot_be_empty = 'The_price_cannot_be_empty';
  static const insert_price = 'insert_price';
  static const The_quantity_cannot_be_empty = 'The_quantity_cannot_be_empty';
  static const insert_quantity = 'insert_quantity';
  static const submit = 'submit';
  static const Activation_Status = 'Activation_Status';
  static const wrong_password = 'wrong_password';
  static const Add_to_card = 'Add_to_card';
  static const Product_added_to_cart = 'Product_added_to_cart';
  static const Done = 'Done';
  static const available = 'available';
  static const unavailable = 'unavailable';
  static const ok = 'ok';
  static const color = 'color';
  static const Well_Done = 'Well_Done';
  static const Product_successfully_added = 'Product_successfully_added';
  static const edit = 'edit';
  static const editing_product = 'editing_product';
  static const Payment = 'Payment';
  static const Shopping_cart = 'Shopping_cart';
  static const Total_cost_is = 'Total_cost_is';
  static const No_image_selected = 'No_image_selected';
  static const not_same_pass_entered = 'not_same_pass_entered';
  static const user_successfully_added = 'user_successfully_added';
  static const search = 'search';
  static const same_username = 'same_username';
}

class Locales {
  static const en_US = {
    'Seller_home_page': 'Seller home page',
    'Customer_home_page': 'Customer home page',
    'Login': 'Login',
    'sign_up': 'sign up',
    'Remember_me': 'Remember me',
    'password': 'password',
    'Add_to_cart': 'Add to cart',
    'log_in_to_enter_the_shop': 'log in to enter the shop',
    'username': 'username',
    'To_sell_or_buy_a_product_you_will_need_a_free_account':
        'To sell or buy a product you\'ll need a free account',
    'username_cannot_be_empty': 'username cannot be empty',
    'Enter_your_username': 'Enter your username',
    'password_cannot_be_empty': 'password cannot be empty',
    'Enter_your_password': 'Enter your password',
    'Do_not_have_an_account__': 'Do not have an account  ',
    'You_must_sign_up_first': 'You must sign up first',
    'Enter_your_first_name': 'Enter your first name',
    'first_name': 'first name',
    'first_name_cannot_be_empty': 'first name cannot be empty',
    'Enter_your_last_name': 'Enter your last name',
    'last_name': 'last name',
    'last_name_cannot_be_empty': 'last name cannot be empty',
    'Repeat_your_password': 'Repeat your password',
    'repeat_password': 'repeat password',
    'this_field_cannot_be_empty': 'this field cannot be empty',
    'Select_Your_Role': 'Select Your Role',
    'customer': 'customer',
    'seller': 'seller',
    'Filters': 'Filters',
    'filter_by_price': 'filter by price',
    'filter': 'filter',
    'Adding_product': 'Adding product ...',
    'The_title_cannot_be_empty': 'The title cannot be empty',
    'insert_title': 'insert title',
    'insert_description': 'insert description',
    'The_description_cannot_be_empty': 'The description cannot be empty',
    'The_price_cannot_be_empty': 'The price cannot be empty',
    'insert_price': 'insert price',
    'The_quantity_cannot_be_empty': 'The quantity cannot be empty',
    'insert_quantity': 'insert quantity',
    'submit': 'submit',
    'Activation_Status': 'Activation Status:     ',
    'wrong_password': 'wrong password',
    'Add_to_card': 'Add to card\'',
    'Product_added_to_cart': 'Product added to cart',
    'Done': 'Done',
    'available': 'available',
    'unavailable': 'unavailable',
    'ok': 'ok',
    'color': 'color',
    'Well_Done': 'Well Done',
    'Product_successfully_added': 'Product successfully added',
    'edit': 'edit',
    'editing_product': 'editing product . . .',
    'Payment': 'Payment',
    'Shopping_cart': 'Shopping cart',
    'Total_cost_is': 'Total cost is',
    'No_image_selected': 'No image selected',
    'not_same_pass_entered': 'same password doesnt enterd',
    'user_successfully_added': 'user successfully added',
    'search': 'search',
    'same_username': 'same username entered',
  };
  static const fa_IR = {
    'Seller_home_page': 'صفحه اصلی فروشنده',
    'Customer_home_page': 'صفحه اصلی مشتری',
    'Login': 'ورود',
    'sign_up': 'ثبت نام',
    'Remember_me': 'مرا به خاطر داشته باش',
    'password': 'رمز عبور',
    'Add_to_cart': 'اضافه به سبد خرید',
    'log_in_to_enter_the_shop': 'برای ورود به فروشکاه وارد شوید',
    'username': 'نام کاربری',
    'To_sell_or_buy_a_product_you_will_need_a_free_account':
        'برای فروش یا خرید یک محصول به یک حساب کاربری رایگان نیاز دارید',
    'username_cannot_be_empty': 'نام کاربری نمی تواند خالی باشد',
    'Enter_your_username': 'نام کاربری خود را وارد کنید',
    'password_cannot_be_empty': 'رمز عبور نمی تواند خالی باشد',
    'Enter_your_password': 'رمز عبور خود را وارد کنید',
    'Do_not_have_an_account__': 'حساب کاربری ندارید  ',
    'You_must_sign_up_first': 'ابتدا باید ثبت نام کنید',
    'Enter_your_first_name': 'نام خود را وارد نمایید',
    'first_name': 'نام',
    'first_name_cannot_be_empty': 'نام نمی تواند خالی باشد',
    'Enter_your_last_name': 'نام خانوادگی خود را وارد کنید',
    'last_name': 'نام خانوادگی',
    'last_name_cannot_be_empty': 'نام خانوادگی نمی تواند خالی باشد',
    'Repeat_your_password': 'رمز عبور خود را تکرار کنید',
    'repeat_password': 'تکرار رمز عبور',
    'this_field_cannot_be_empty': 'این فیلد نمی تواند خالی باشد',
    'Select_Your_Role': 'نقش خود را انتخاب کنید',
    'customer': 'مشتری',
    'seller': 'فروشنده',
    'Filters': 'فیلترها',
    'filter_by_price': 'فیلتر بر اساس هزینه',
    'filter': 'فیلتر',
    'Adding_product': 'اضافه کردن محصول ',
    'The_title_cannot_be_empty': 'عنوان نمیتواند خالی باشد',
    'insert_title': 'عنوان را وارد کنید',
    'insert_description': 'توضیحات را وارد کنید',
    'The_description_cannot_be_empty': 'توضیحات نمیتواند خالی باشد',
    'The_price_cannot_be_empty': 'قیمت نمیتواند خالی باشد',
    'insert_price': 'قیمت را وارد کنید',
    'The_quantity_cannot_be_empty': 'مقدار نمیتواند خالی باشد',
    'insert_quantity': 'مقدار را وارد کنید',
    'submit': 'تایید',
    'Activation_Status': 'وضعیت فعال بودن محصول',
    'wrong_password': 'رمز عبور نادرست است',
    'Add_to_card': 'اضافه به سبد خرید',
    'Product_added_to_cart': 'محصول به سبد اضافه شد',
    'Done': 'انجام شد',
    'available': 'در دسترس فروش',
    'unavailable': 'خارج از دسترس',
    'ok': 'تایید',
    'color': 'رنگ',
    'Well_Done': 'انجام شد',
    'Product_successfully_added': 'محصول با موفقیت اضافه شد',
    'edit': 'ویرایش',
    'editing_product': 'ویرایش محصول',
    'Payment': 'خرید',
    'Shopping_cart': 'سبد خرید',
    'Total_cost_is': 'جمع کل برابر است با',
    'No_image_selected': 'تصویری انتخاب نکردید',
    'not_same_pass_entered': 'پسورد یکسان وارد نشده است',
    'user_successfully_added': 'کاربر با موفقیت اضافه شد',
    'search': 'جستجو',
    'same_username': 'نام کاربری تکراری است',
  };
}
