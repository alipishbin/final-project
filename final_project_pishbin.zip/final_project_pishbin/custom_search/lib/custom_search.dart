library custom_search;

import 'package:flutter/material.dart';

class CustomSearchBar extends StatefulWidget {
  const CustomSearchBar(
      {required this.onClearSearchTap,
      required this.onFilterButtonTap,
      required this.searchTextController,
      required this.onSearchTextFieldChanged,
      super.key});

  final VoidCallback onFilterButtonTap;
  final VoidCallback onClearSearchTap;
  final TextEditingController searchTextController;
  final Function(String) onSearchTextFieldChanged;

  @override
  State<CustomSearchBar> createState() => _CustomSearchBarState();
}

class _CustomSearchBarState extends State<CustomSearchBar> {
  @override
  Widget build(BuildContext context) => _buildBody();

  Widget _buildBody() => Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            IconButton(
              onPressed: () => widget.onFilterButtonTap(),
              icon: const Icon(Icons.filter_list),
            ),
            const SizedBox(
              width: 8,
            ),
            Expanded(child: _searchTextField()),
          ],
        ),
      );

  Widget _searchTextField() {
    return TextField(
      controller: widget.searchTextController,
      onChanged: (value) => widget.onSearchTextFieldChanged(value),
      decoration: InputDecoration(
        contentPadding: const EdgeInsets.symmetric(vertical: 6),
        filled: true,
        fillColor: Colors.blueGrey.shade100,
        label: const Text('search'),
        hintText: 'search',
        border: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.blueGrey),
          borderRadius: BorderRadius.circular(8),
        ),
        suffix: IconButton(
          onPressed: () => widget.onClearSearchTap(),
          icon: const Icon(Icons.clear),
        ),
        prefix: const Icon(Icons.search),
      ),
    );
  }
}
